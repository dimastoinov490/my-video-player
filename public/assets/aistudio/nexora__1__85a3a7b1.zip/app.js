(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const ico = (n) => `<svg><use href="#i-${n}"/></svg>`;

  /* ---------- данные ---------- */
  const videos = [
    { id: 'v1', name: '2026-11-06-122610901.mp4', dur: '20:06', fmt: 'MP4', res: '720p', src: 'media/v1.mp4', title: 'ВОЙНА\nНЕ ТОЛЬКО', c: ['#9fb4b8', '#e8eef0'] },
    { id: 'v2', name: '2026-11-06-122610902.mp4', dur: '20:06', fmt: 'MP4', res: '720p', src: 'media/v1.mp4', title: 'ВОЙНА\nНЕ ТОЛЬКО', c: ['#a9b9a9', '#eef2ee'] },
    { id: 'v3', name: 'c670a1b5808fa73482b1.mp4', dur: '67:08', fmt: 'MP4', res: '1080p', src: 'media/v2.mp4', title: 'BLADE\nRACER', c: ['#2f6d5f', '#a9d6c5'] },
    { id: 'v4', name: 'ночной-город-таймлапс.mp4', dur: '03:42', fmt: 'MP4', res: '1080p', src: 'media/v2.mp4', title: 'НОЧНОЙ\nГОРОД', c: ['#1b2a6b', '#6b8cff'] },
    { id: 'v5', name: 'поездка-на-море.mp4', dur: '12:15', fmt: 'MP4', res: '720p', src: 'media/v1.mp4', title: 'МОРЕ', c: ['#0a7fa8', '#9ee6ff'] },
    { id: 'v6', name: 'семейный-архив-2025.mp4', dur: '45:30', fmt: 'MP4', res: '1080p', src: 'media/v2.mp4', title: 'АРХИВ\n2025', c: ['#8a5a2b', '#f0cf9a'] },
  ];
  const audios = [
    { id: 'a1', name: 'Утренний плейлист — часть 1', art: 'Нексора', dur: '00:12', src: 'media/a1.mp3' },
    { id: 'a2', name: 'Фоновая музыка для работы', art: 'Нексора', dur: '00:12', src: 'media/a2.mp3' },
  ];
  const folders = [
    { id: 'f1', name: 'Камера', info: '412 файлов', size: '312 MB' },
    { id: 'f2', name: 'Загрузки', info: '255 файлов', size: '541.3 MB' },
  ];
  const PHOTO_TOTAL = 661;
  const palette = [['#ff9a8b', '#ff6a88'], ['#43e97b', '#38f9d7'], ['#4facfe', '#00f2fe'], ['#fa709a', '#fee140'], ['#a18cd1', '#fbc2eb'], ['#f6d365', '#fda085'], ['#30cfd0', '#330867'], ['#5ee7df', '#b490ca']];
  const photo = (i) => {
    const [a, b] = palette[(i * 5) % palette.length];
    return { i, a, b, name: `IMG_${String(2000 + i).padStart(4, '0')}.jpg`, angle: (i * 37) % 360 };
  };
  const photoSvg = (p) => 'data:image/svg+xml,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800"><defs><linearGradient id="g" gradientTransform="rotate(${p.angle})"><stop offset="0" stop-color="${p.a}"/><stop offset="1" stop-color="${p.b}"/></linearGradient></defs><rect width="1200" height="800" fill="url(#g)"/><circle cx="${300 + (p.i * 53) % 600}" cy="260" r="120" fill="#fff" opacity=".35"/><path d="M0 800V600q300-200 600-60t600-100V800z" fill="#fff" opacity=".28"/></svg>`);

  const TOTAL_GB = 18.4, USED_MB = 853.3;
  const state = {
    view: 'home', q: '', photosShown: 48, online: true,
    settings: Object.assign({ autoplay: true, thumbs: true, lang: 'ru' }, JSON.parse(localStorage.getItem('nx') || '{}')),
  };
  const save = () => localStorage.setItem('nx', JSON.stringify(state.settings));

  /* ---------- шаблоны ---------- */
  const thumbStyle = (v) => `background:linear-gradient(135deg,${v.c[0]},${v.c[1]})`;
  const videoRow = (v) => `
    <div class="row" role="button" tabindex="0" data-play="${v.id}">
      <div class="thumb" style="${state.settings.thumbs ? thumbStyle(v) : 'background:#cfdff5'}">
        <span class="t-title">${v.title.replace('\n', '<br>')}</span>
        <span class="play">${ico('play')}</span><span class="dur">${v.dur}</span>
      </div>
      <div class="meta"><h3>${v.name}</h3><p>${v.fmt} &bull; ${v.res}</p></div>
      <button class="more" data-more="${v.id}" aria-label="Действия">${ico('dots')}</button>
    </div>`;
  const stat = (cls, icon, n, label, view) =>
    `<button class="stat ${cls}" data-go="${view}">${ico(icon)}<div><b data-count="${n}">0</b><span>${label}</span></div></button>`;

  const views = {
    home: () => `
      <section class="stats">
        ${stat('v', 'play-o', videos.length, 'Видео', 'video')}
        ${stat('a', 'note', audios.length, 'Аудио', 'audio')}
        ${stat('p', 'image', PHOTO_TOTAL, 'Фото', 'photo')}
        ${stat('f', 'folder', folders.length, 'Папки', 'folders')}
      </section>
      <div class="sec-head"><h2>Последние видео</h2><button class="link" data-go="video">Все ${ico('arrow')}</button></div>
      <div class="list">${videos.slice(0, 3).map(videoRow).join('')}</div>`,
    video: () => {
      const l = videos.filter((v) => v.name.toLowerCase().includes(state.q));
      return `<div class="sec-head"><h2>Видео</h2></div><div class="list">${l.map(videoRow).join('') || '<p class="empty">Ничего не найдено</p>'}</div>`;
    },
    audio: () => {
      const l = audios.filter((a) => a.name.toLowerCase().includes(state.q));
      return `<div class="sec-head"><h2>Аудио</h2></div><div class="tracks">${l.map((a) => `
        <button class="track glass" data-audio="${a.id}"><span class="cover">${ico('note')}</span>
        <div><h3>${a.name}</h3><p>${a.art}</p></div><span class="dur2">${a.dur}</span></button>`).join('') || '<p class="empty">Ничего не найдено</p>'}</div>`;
    },
    photo: () => {
      const all = Array.from({ length: PHOTO_TOTAL }, (_, i) => photo(i + 1)).filter((p) => p.name.toLowerCase().includes(state.q));
      const shown = all.slice(0, state.photosShown);
      return `<div class="sec-head"><h2>Фото</h2><span class="link" style="cursor:default;font-size:16px;color:var(--muted)">${all.length} шт.</span></div>
        <div class="gallery">${shown.map((p) => `<button class="shot" data-photo="${p.i}" style="background:linear-gradient(${p.angle}deg,${p.a},${p.b})"><span>${p.name}</span></button>`).join('')}</div>
        ${shown.length < all.length ? '<button class="more-btn glass" data-morephotos>Показать ещё</button>' : ''}
        ${!all.length ? '<p class="empty">Ничего не найдено</p>' : ''}`;
    },
    folders: () => `<div class="sec-head"><h2>Папки</h2></div><div class="folders">${folders
      .filter((f) => f.name.toLowerCase().includes(state.q))
      .map((f) => `<button class="folder glass" data-folder="${f.id}">${ico('folder')}<h3>${f.name}</h3><p>${f.info} &bull; ${f.size}</p></button>`).join('')}</div>`,
    settings: () => `<div class="sec-head"><h2>Настройки</h2></div><div class="settings">
      ${setRow('autoplay', 'Автовоспроизведение', 'Запускать видео сразу после открытия')}
      ${setRow('thumbs', 'Превью видео', 'Показывать обложки в списках')}
      <div class="set glass"><div><h3>Язык интерфейса</h3><p>Применяется после перезагрузки</p></div>
        <select data-lang><option value="ru">Русский</option><option value="en">English</option></select></div>
      <div class="set glass"><div><h3>Адрес сервера</h3><p>${location.host || 'localhost'}</p></div></div></div>`,
  };
  const setRow = (k, t, d) => `<div class="set glass"><div><h3>${t}</h3><p>${d}</p></div>
    <button class="switch" role="switch" data-set="${k}" aria-checked="${state.settings[k]}" aria-label="${t}"></button></div>`;

  /* ---------- рендер ---------- */
  const main = $('#main'), app = $('#app');
  function render() {
    app.dataset.view = state.view;
    $$('.nav').forEach((n) => n.classList.toggle('active', n.dataset.view === state.view));
    main.innerHTML = `<div class="view-in">${views[state.view]()}</div>`;
    $('[data-lang]', main) && ($('[data-lang]', main).value = state.settings.lang);
    countUp();
  }
  function go(v) { state.view = v; state.q = ''; state.photosShown = 48; $('#search').value = ''; render(); window.scrollTo({ top: 0, behavior: 'smooth' }); }

  function countUp() {
    $$('[data-count]').forEach((el) => {
      const n = +el.dataset.count, t0 = performance.now();
      const step = (t) => { const k = Math.min((t - t0) / 800, 1); el.textContent = Math.round(n * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }

  /* ---------- хранилище ---------- */
  function storage() {
    const pct = USED_MB / 1024 / TOTAL_GB * 100;
    $('#usedTxt').textContent = USED_MB.toFixed(1) + ' MB';
    $('#totalTxt').textContent = TOTAL_GB + ' GB';
    $('#pctTxt').textContent = pct.toFixed(1) + '%';
    $('#freeTxt').textContent = (TOTAL_GB - USED_MB / 1024).toFixed(1) + ' GB';
    requestAnimationFrame(() => setTimeout(() => {
      $('#barFill').style.width = pct + '%';
      $('#ringFg').style.strokeDashoffset = 326.7 * (1 - pct / 100);
    }, 120));
  }

  /* ---------- плеер ---------- */
  const dlg = $('#player'), body = $('#pBody');
  function openPlayer(title, meta, html) {
    $('#pTitle').textContent = title; $('#pMeta').textContent = meta; body.innerHTML = html;
    dlg.showModal();
    const m = $('video,audio', body);
    if (m && state.settings.autoplay) m.play().catch(() => {});
  }
  function closePlayer() { const m = $('video,audio', body); m && m.pause(); dlg.close(); body.innerHTML = ''; }
  $('#pClose').onclick = closePlayer;
  dlg.addEventListener('click', (e) => { if (e.target === dlg) closePlayer(); });
  dlg.addEventListener('cancel', () => setTimeout(() => (body.innerHTML = ''), 0));

  function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2200); }

  /* ---------- события ---------- */
  document.addEventListener('click', (e) => {
    const t = e.target;
    let el;
    if ((el = t.closest('.menu button'))) { menuAction(el.dataset.act, el.dataset.id); return; }
    $$('.menu').forEach((m) => m.remove());
    if ((el = t.closest('[data-more]'))) {
      e.stopPropagation();
      el.insertAdjacentHTML('beforeend', `<div class="menu"><button data-act="play" data-id="${el.dataset.more}">Воспроизвести</button><button data-act="copy" data-id="${el.dataset.more}">Скопировать ссылку</button><button data-act="info" data-id="${el.dataset.more}">Свойства</button></div>`);
    } else if ((el = t.closest('[data-play]'))) playVideo(el.dataset.play);
    else if ((el = t.closest('[data-go]'))) go(el.dataset.go);
    else if ((el = t.closest('.nav'))) go(el.dataset.view);
    else if ((el = t.closest('[data-audio]'))) { const a = audios.find((x) => x.id === el.dataset.audio); openPlayer(a.name, a.art, `<div class="art" style="background:linear-gradient(135deg,#43d95a,#0d6e8f)">${ico('note')}</div><audio controls src="${a.src}"></audio>`); }
    else if ((el = t.closest('[data-photo]'))) { const p = photo(+el.dataset.photo); openPlayer(p.name, 'Фото', `<img alt="${p.name}" src="${photoSvg(p)}">`); }
    else if (t.closest('[data-morephotos]')) { state.photosShown += 48; render(); }
    else if ((el = t.closest('[data-folder]'))) toast('Папка «' + folders.find((f) => f.id === el.dataset.folder).name + '» пуста в демо-версии');
    else if ((el = t.closest('[data-set]'))) { const k = el.dataset.set; state.settings[k] = !state.settings[k]; el.setAttribute('aria-checked', state.settings[k]); save(); }
    else if (t.closest('#menuBtn')) go('settings');
    else if (t.closest('#status')) { state.online = !state.online; $('#status').classList.toggle('off', !state.online); $('#statusTxt').textContent = state.online ? 'Сервер онлайн' : 'Сервер офлайн'; }
  });
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.row')) { e.preventDefault(); playVideo(e.target.dataset.play); }
  });
  document.addEventListener('change', (e) => { if (e.target.matches('[data-lang]')) { state.settings.lang = e.target.value; save(); toast('Язык сохранён'); } });
  $('#search').addEventListener('input', (e) => {
    state.q = e.target.value.trim().toLowerCase();
    if (state.q && state.view === 'home') state.view = 'video';
    render();
  });

  function playVideo(id) {
    const v = videos.find((x) => x.id === id);
    openPlayer(v.name, `${v.fmt} • ${v.res} • ${v.dur}`, `<video controls playsinline src="${v.src}"></video>`);
  }
  function menuAction(act, id) {
    $$('.menu').forEach((m) => m.remove());
    const v = videos.find((x) => x.id === id);
    if (act === 'play') playVideo(id);
    if (act === 'copy') { navigator.clipboard?.writeText(new URL(v.src, location.href).href); toast('Ссылка скопирована'); }
    if (act === 'info') toast(`${v.name} — ${v.fmt}, ${v.res}, ${v.dur}`);
  }

  /* сцена 1600x900 (16:9): один коэффициент масштаба, поля вместо растяжения.
     Портретное окно -> сцена поворачивается на 90°. Сдвиг округляется до
     физического пикселя (devicePixelRatio), чтобы края оставались чёткими. */
  function fit() {
    const W = innerWidth, H = innerHeight, rot = H > W, dpr = devicePixelRatio || 1;
    const vw = rot ? H : W, vh = rot ? W : H;
    const s = Math.min(vw / 1600, vh / 900);
    const snap = (v) => Math.round(v * dpr) / dpr;
    const r = document.documentElement.style;
    r.setProperty('--s', s);
    r.setProperty('--r', rot ? '90deg' : '0deg');
    r.setProperty('--tx', snap(rot ? (W + 900 * s) / 2 : (W - 1600 * s) / 2) + 'px');
    r.setProperty('--ty', snap(rot ? (H - 1600 * s) / 2 : (H - 900 * s) / 2) + 'px');
  }
  addEventListener('resize', fit); addEventListener('orientationchange', fit);
  fit();
  /* по возможности просим систему удерживать альбомную ориентацию (нужен fullscreen/PWA) */
  addEventListener('click', () => { try { screen.orientation?.lock?.('landscape').catch(() => {}); } catch (e) {} }, { once: true });

  render();
  storage();
})();
